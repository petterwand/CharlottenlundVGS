#ifndef CAR_H
#define CAR_H

#include <Servo.h>
#include <Arduino.h>

#define speedOfSound 0.034 //cm/us
#define pinLB 6
#define pinLF 9
#define pinRB 10
#define pinRF 11
#define ultraSonicInput A0
#define ultraSonicOutput A1
#define servoPin 5
#define servoStartPosition 90

class Car{
  Servo sensorServo;
  int distanceToObject = 0;
  
  // Variabler knyttet til ufulstendige funksjoner
  bool objectSpotted = false;
  bool objectToRight = false;
  bool objectToLeft = false;

public:
  
  void init();
  void forward();
  void backward();
  void left();
  void right();
  void stop();
  void turnLeft();
  void turnRight();
  int readDistance();


//        Funksjoner som enda ikke er komplett           //
// ##################################################### //

  bool getObjectSpotted() const {return objectSpotted;}
  bool getObjectToRight() const {return objectToRight;}
  bool getObjectToLeft() const {return objectToLeft;}
  
  void lookForObstacles();
  void lookForObstaclesLeft();
  int spotObstaclesLeft();

  void lookForObstaclesRight();
  int spotObstaclesRight();
  
// ##################################################### //

};


#endif
