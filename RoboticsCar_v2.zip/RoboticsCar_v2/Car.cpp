#include "Car.h"
/*! \brief Denne funksjonen initierer innganger og utganger.
Funksjonen må kjøres i void setup()
*/
void Car::init(){
  Serial.begin(9600);
  pinMode(pinLB,OUTPUT);
  pinMode(pinLF,OUTPUT);
  pinMode(pinRB,OUTPUT);
  pinMode(pinRF,OUTPUT);
  pinMode(ultraSonicInput, INPUT);
  pinMode(ultraSonicOutput, OUTPUT);
  sensorServo.attach(servoPin); // define the servo pin(PWM)
  delay(20);
  sensorServo.write(90);
  delay(2000);
}

/*! \brief Denne funksjonene gjør at bilen kjører framover */
void Car::forward(){
  digitalWrite(pinRB,HIGH);
  digitalWrite(pinRF,LOW);
  digitalWrite(pinLB,HIGH);
  digitalWrite(pinLF,LOW);
  
}

/*! \brief Denne funksjonen gjør at bilen kjører bakover */
void Car::backward(){
  digitalWrite(pinRB,LOW);
  digitalWrite(pinRF,HIGH);
  digitalWrite(pinLB,LOW);
  digitalWrite(pinLF,HIGH);
  //delay(g * 300);
}

/*! \brief Denne funksjonen gjør at bilen snur seg mot venstre */
void Car::turnLeft(){
  digitalWrite(pinRB,LOW);
  digitalWrite(pinRF,HIGH);
  digitalWrite(pinLB,HIGH);
  digitalWrite(pinLF,LOW);
}

/*! \brief Denne funksjonen gjør at bilen snur seg mot høyre */
void Car::turnRight(){
  digitalWrite(pinRB,HIGH);
  digitalWrite(pinRF,LOW);
  digitalWrite(pinLB,LOW);
  digitalWrite(pinLF,HIGH);
}

/*! \brief Denne funksjonen gjør at bilen stopper */
void Car::stop(){
  digitalWrite(pinRB,HIGH);
  digitalWrite(pinRF,HIGH);
  digitalWrite(pinLB,HIGH);
  digitalWrite(pinLF,HIGH);
  //objectSpotted = false;
}

/*! \brief Returnerer avstand fra sensor til objekt
Denne funksjonen kalkulerer avstand fra ultrasonisk sensor
til objekt og returnerer avstandsverdien
*/
int Car::readDistance(){
  delay(10);
  digitalWrite(ultraSonicOutput, LOW);
  delayMicroseconds(4);
  digitalWrite(ultraSonicOutput, HIGH);
  delayMicroseconds(20);
  digitalWrite(ultraSonicOutput, LOW);
  delayMicroseconds(20);
  return 0.5*speedOfSound*pulseIn(ultraSonicInput, HIGH);
}

// Funksjoner som enda ikke er komplett
// ####################################

/*
Tanker her er at servoen skal "se seg rundt" og lese avstand samtidig.
Hvis man legger readDistance() inn i en for-løkke, så vil servoen rotere
ekstremt sakte. Derfor ligger den utenfor for-løkken

Så det jeg føler at vi mangler er å løse dette på en enkel og forståelig 
måte så elevene kan bruke funksjoer til å avgjøre om et objekt er på venstre
side og dermed snu bilen mot høyre og kjøre videre
*/

void Car::lookForObstacles(){
  if (readDistance() < 10){
    Serial.println(readDistance());
    objectSpotted = true;
  }
}

void Car::lookForObstaclesRight(){
  sensorServo.write(servoStartPosition);
  for(int i = 90; i < 160; i++){
    sensorServo.write(i);
    delay(10);
  }
  readDistance();
  if (getDistance() < 30){
    objectToRight = true;
  }  
}
void Car::lookForObstaclesLeft(){
  sensorServo.write(servoStartPosition);
  for(int i = 90; i > 20; i--){
    sensorServo.write(i);
    delay(10);
  }
  readDistance();
  if (getDistance() < 30){
    objectToLeft = true;
  }  
}

int Car::spotObstaclesRight(){
  sensorServo.write(servoStartPosition);
  for(int i = 90; i < 160; i++){
    sensorServo.write(i);
    delay(5);
  }
  readDistance();
  return distanceToObject;
}
int Car::spotObstaclesLeft(){
  sensorServo.write(servoStartPosition);
  for(int i = 90; i > 20; i--){
    sensorServo.write(i);
    delay(5);
  }
  readDistance();
  return distanceToObject;
}
// ####################################
